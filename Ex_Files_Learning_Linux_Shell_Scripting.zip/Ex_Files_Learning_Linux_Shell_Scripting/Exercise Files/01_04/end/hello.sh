#!/usr/bin/env bash


# Displays a greeting

echo Hello, World.
echo Mars is red.
