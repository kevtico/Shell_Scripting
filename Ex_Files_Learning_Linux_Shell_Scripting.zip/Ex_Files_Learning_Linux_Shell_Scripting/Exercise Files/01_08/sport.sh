#!/usr/bin/env bash

# Sport script - uses parameters

NAME=$1
SPORT=$2

# Prints the name and SPORT

echo $NAME likes to watch $SPORT.
