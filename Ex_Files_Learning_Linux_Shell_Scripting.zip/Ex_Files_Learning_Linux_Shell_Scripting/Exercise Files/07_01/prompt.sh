#!/usr/bin/env bash

read -p "What is your first name: " NAME
echo "Your name is: $NAME"
exit 0
