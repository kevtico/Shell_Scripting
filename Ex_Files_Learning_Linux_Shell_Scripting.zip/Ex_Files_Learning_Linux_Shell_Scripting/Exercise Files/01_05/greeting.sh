#!/usr/bin/env bash

NAME="Bob Roberts"
FAVORITE_COLOR=blue

echo Hi $NAME, your favorite color is $FAVORITE_COLOR.
